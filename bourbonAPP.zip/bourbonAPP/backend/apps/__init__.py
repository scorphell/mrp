"""Apps de negócio do Projeto 7 (Smart Check-In & Credenciamento).

Pacote contêiner para os apps Django do backend: ``registry`` (cadastro de
equipes/membros/veículos/sessões) e ``checkin`` (presença e conformidade).
Apps de ``core`` e ``credentials`` entram em marcos posteriores (M2/M3).
"""
