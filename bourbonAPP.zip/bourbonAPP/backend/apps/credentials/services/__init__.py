"""Serviços de credenciais: assinatura (crypto pura), orquestração e renderização."""
