# Análise Jurídica: Mousetrap Racing Project 2026 — Direitos dos Estudantes sobre Trabalho Acadêmico

## Contexto

O documento **"Mousetrap Racing Project 2026 — Caderno de Projetos Interdisciplinares"** apresenta 25 propostas de projetos interdisciplinares para a UC *Exploração Digital e Fundamentos Tecnológicos*. Os estudantes recebem um **bônus de 20% na nota A3** como compensação. A questão central é: **o Bourbon Shopping pode lucrar comercialmente com os softwares produzidos pelos alunos?**

---

## Legislação Aplicável

### 1. Lei 9.610/1998 — Direitos Autorais

> **Art. 11.** É autor da obra literária, artística ou científica a pessoa física que a cria.

> **Art. 28.** Ao autor de obra literária, artística ou científica é assegurado o direito exclusivo de utilizá-la, fruir dela e dispor dela.

> **Art. 29.** Ninguém poderá reproduzir, plagiar, editar, adaptar, traduzir, distribuir, comunicar ao público, em converter ou, por qualquer outro meio, obra intelectual, no todo ou em parte, sem autorização prévia do autor.

- **Proteção automática:** não exige registro; vale desde a criação.
- **Titular:** a pessoa física que criou a obra.
- **Moral e patrimonial:** ambos pertencem ao autor.

### 2. Lei 9.609/1998 — Software

> **Art. 1º.** O software, misunderstood como programa de computador, em qualquer modo ou linguagem de expressão, bem como o material de concepção preparatória, a documentação, as instruções de uso e o código-fonte-objeto, são protegidos...

> **Art. 4º.** Cessão e licenciamento de direitos do software.
> - **§ 1º.** Na hipótese de o software ter sido encomendado, a titularidade do programa e dos direitos patrimoniais dele decorrentes pertencerá ao encomendante, desde que expressamente previsto no contrato de encomenda.
> - **§ 2º.** Na ausência de previsão contratual expressa, o software pertence ao empregador, desde que o contrato de trabalho previra a elaboração de software.
> - **§ 3º.** **O tratamento previsto neste artigo será aplicado nos casos em que o programa de computador for desenvolvido por bolsistas, estagiários e assemelhados.**

**Implicação direta:** a universidade **não** é empregadora dos alunos — é instituição de ensino. Se não há contrato de cessão de direitos com o Bourbon Shopping, **os softwares permanecem sob titularidade dos estudantes que os criaram.**

### 3. Lei 11.788/2008 — Estágios

> **Art. 1º.** Estágio é ato educacional escolar监督ado e supervisionado, ministrado pela instituição de ensino em parceria com organizações... compatível com o projeto pedagógico.

- O edital não prevê Termo de Compromisso de Estágio (TCE).
- Atividades sem vínculo formal de estágio e sem subordinação não configuram relação de trabalho formal, mas a ausência de termo expresso pode gerar riscos jurídicos.

### 4. Lei 13.243/2016 + Lei 10.973/2004 — Marco Legal da Inovação

> **Art. 9º, § 2º.** Os contratos e termos de cooperação firmados entre ICTs [Instituições Científicas e Tecnológicas] e pessoas jurídicas devem prever, no que couber:
> - I — os direitos e obrigações das partes;
> - II — o objeto, a finalidade e o cronograma;
> - III — as condições de pagamento;
> - IV — **as condições de transferência e compartilhamento de tecnologia;**
> - V — **a titularidade e a forma de exploração dos resultados;**

**Implicação:** o projeto descrito não apresenta contrato de parceria firmado entre a universidade e o Bourbon Shopping. Sem esse contrato, **a titularidade dos resultados pertence aos criadores.**

### 5. CLT — Vínculo Empregatício

> **Art. 3º.** Considera-se empregado toda pessoa física que prestar serviço de natureza não eventual a empregador, sob a dependência deste e mediante salário.

- Se o Bourbon usar o trabalho continuamente, com subordinação e habitualidade, sem TCE, **pode configurar vínculo empregatício** com todos os direitos trabalhistas.

---

## Quadro Resumo — Situação Jurídica

| Situação | Artigos Aplicáveis | Resultado |
|---|---|---|
| Bourbon usa softwares sem contrato de cessão | Lei 9.610, Arts. 11, 28, 29 | Alunos mantêm direitos autorais exclusivos |
| Não há termo formal de transferência de PI | Lei 13.243, Art. 9º, § 2º | Bourbon não tem legitimidade para exploração comercial |
| Não há Termo de Compromisso de Estágio | Lei 11.788, Art. 1º | Pode configurar relação empregatícia irregular (CLT, Art. 3º) |
| Alunos são bolsistas/estagiários | Lei 9.609, Art. 4º, § 3º | Software permanece sob titularidade dos alunos |
| Universidade não formalizou parceria | Lei 13.243, Art. 9º | Universidade também responde por falta de contrato |
| Chamar de "atividade pedagógica" | Lei 9.610, Art. 28 | Não anula direitos autorais automáticos |

---

## Quadro de Riscos

### Para os Estudantes

- **Risco de perda de PI:** se não houver contrato escrito, podem perder o direito de uso comercial do próprio código
- **Risco de vínculo empregatício:** atividades continuadas sem TCE podem gerar direitos trabalhistas reclamáveis
- **Risco de confidencialidade:** o edital não prevê cláusulas de sigilo, portanto dados de terceiros podem estar expostos em ferramentas desenvolvidas

### Para o Bourbon Shopping

- **Risco de exploração não autorizada:** usar softwares sem cessão formal configura violação de direitos autorais (Art. 29, Lei 9.610)
- **Risco de passivo trabalhista:** se houver subordinação, habitualidade e onerosidade, pode ser reconhecido empregador

### Para a Universidade

- **Risco de responsabilidade solidária:** por não ter formalizado contrato de parceria conforme Lei 13.243
- **Risco ético-pedagógico:** apresentar atividade comercial como meramente acadêmica sem esclarecer os direitos dos alunos

---

## Recomendações Práticas

1. **Exigir contrato de cessão/parceria** — Antes de iniciar a execução, a universidade deve formalizar acordo com o Bourbon Shopping definiendo:
   - Quem detém os direitos sobre os softwares produzidos
   - Se há cessão parcial ou integral
   - Quais são as condições de uso comercial
   - Quais dados serão coletados e como serão protegidos

2. **Termo de Compromisso de Estágio** — Se houver qualquer forma de remuneração além do bônus na nota (vale-refeição, vale-transporte, materiais fornecidos), o TCE deve ser formalizado

3. **Cláusula de não-exclusividade** — Os alunos devem ter direito de usar o software produzido em portfólio profissional e para fins acadêmicos

4. **Registro formal de autoria** — Cada projeto deve registrar formalmente os autores (nome, RA, e-mail institucional) e a data de entrega, servindo como prova de autoria

5. **LGPD compliance** — Toda ferramenta que coletar dados de terceiros (votos, imagens, dados pessoais) deve ter Termo de Consentimento

6. **Comunicação clara** — O edital deve esclarecer de forma transparente que os softwares produzidos permanecem sob titularidade dos estudantes, salvo contrato formal em contrário

---

## Conclusão

Chamar o projeto de "atividade pedagógica" **não anula** os direitos autorais automáticos dos estudantes. A Lei 9.610 protege a obra desde a criação, independentemente de registro. A Lei 9.609 é explícita: sem contrato de cessão expresso, o software permanece sob titularidade de quem o criou — e estudantes bolsistas/estagiários têm proteção específica (Art. 4º, § 3º).

Se o Bourbon Shopping deseja usar comercialmente os softwares produzidos, **precisa formalizar contrato de cessão/parceria** com a universidade e os estudantes. Caso contrário, os alunos têm pleno respaldo legal para impedir a exploração comercial não autorizada de seu trabalho.

---

*Documento elaborado com base na legislação brasileira vigente em 2026. Esta análise não substitui assessoria jurídica profissional.*
