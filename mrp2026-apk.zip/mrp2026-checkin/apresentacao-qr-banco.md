# Como funciona o QR e o banco de dados

Roteiro de 2 a 3 minutos. Fala simples, com exemplos.
No final tem o referencial teórico com os nomes que o sponsor pediu.

## 1. A ideia em uma frase

O celular só lê o QR. Quem diz se vale ou não é o servidor.

Pensa numa balada: o segurança na porta olha sua pulseira, mas é a lista da portaria que diz se você pode entrar. Aqui é igual. O app é o segurança, o servidor é a lista.

## 2. O QR: por que ninguém consegue falsificar?

Exemplo: Maria recebe um QR de piloto. João recebe um QR de carro número 7.

No app, esses dois QRs são só um texto esquisito, tipo:

```
MRP1.eyJrIjoidiIsInRpIjoiLi4uIiwi... .AbC123...
```

O app não entende esse texto. Ele só manda para o servidor:

```
POST /api/v1/checkin/verify
{ "qr_text": "MRP1...", "session_id": 3 }
```

E o servidor responde:

- Maria: `{ valid: true, subject_type: "member", name: "Maria", team: "Trovão" }`
- Carro 7: `{ valid: true, subject_type: "vehicle", name: "Carro 7" }`
- QR inventado no Paint: `{ valid: false }` -> tela mostra "QR inválido"

Por que é seguro? Porque só o servidor tem a chave que assina o QR. É como uma assinatura com caneta invisível. Você pode copiar o desenho, mas não copia a assinatura invisível. Quem confere é o servidor.

Detalhe: o app nunca salva o QR. Leu, perguntou, esqueceu. Fica só na memória por alguns segundos.

## 3. O banco de dados: onde tudo fica guardado?

O celular não guarda nada. Não tem banco dentro do app. Tudo mora no servidor. O app só faz 4 perguntas:

### Pergunta 1: qual evento está aberto?
```
GET /api/v1/sessions?status=open
```
Exemplo: "Treino de sábado de manhã". Assim o bip da Maria cai no evento certo, não mistura treino com corrida.

### Pergunta 2: quem é esse QR?
```
POST /api/v1/checkin/verify
```
É a pergunta da portaria. Exemplo: "esse QR é da Maria, piloto do time Trovão". A partir daí o app mostra dois botões diferentes: se é gente, mostra "Registrar presença". Se é carro, mostra "Conformidade técnica".

### Pergunta 3: marcou presença?
```
POST /api/v1/checkin/presence
```
Exemplo: Maria bipa 8h00 -> `{ duplicate: false }`, presença marcada. Ela bipa de novo 8h05 sem querer -> `{ duplicate: true, last_seen_at: "8h00" }`. O sistema avisa "já marcou" em vez de contar duas vezes. Igual catraca que não deixa passar duas vezes com o mesmo ingresso.

### Pergunta 4: o carro passou na vistoria?
```
POST /api/v1/checkin/conformity
```
Exemplo: o fiscal olha o carro 7, marca "freio ok, peso ok" e manda `result: "pass"`. O servidor guarda `{ conformity_status: "pass", checked_at: "9h12" }`. Se reprovar, fica `fail` e o carro não corre.

### Quem fez o quê?
Toda vez que alguém bipa, o servidor anota: "fiscal Carlos registrou Maria às 8h00". Isso se chama `AuditLog`. Se der problema depois, dá pra saber quem fez. Por LGPD ele não guarda nome nem e-mail, só ids opacos e hash de IP.

## 4. E a senha? E meus dados?

- Login vira um passe de 12 horas (JWT). Acabou o turno, expira. Se um fiscal sair da equipe, é só desativar ele no painel e o passe morre na hora.
- O passe fica guardado num cantinho privado do celular (`SharedPreferences`), que outros apps não leem.
- O app roda numa rede interna do evento, sem internet. Por isso usa HTTP simples.
- O app não salva nome, time nem foto no celular. Só mostra na tela na hora pra você conferir com o olho: "é a Maria mesmo?".

## Frase para fechar

> QR assinado prova que o ingresso é verdadeiro. Banco de dados central prova que ninguém votou duas vezes. Um valida, o outro conta. E o registro diz quem fez.

---

## Anexo técnico — referencial teórico e nomes (para o sponsor)

### Criptografia do QR: Ed25519 (EdDSA)

- **Algoritmo:** Ed25519, assinatura digital de curva elíptica Curve25519 (EdDSA, RFC 8032). Não é AES nem HMAC: é chave pública/privada. Só quem tem a privada assina, qualquer um com a pública verifica.
- **Biblioteca:** `cryptography` (Python) no backend, `PyJWT` com `algorithm="EdDSA"` para o login.
- **Chaves:** par gerado por `backend/scripts/generate_keys.py`:
  - `backend/secrets/ed25519_private.pem` (PEM PKCS8, chmod 600, nunca sai do servidor, fora do git)
  - `backend/secrets/ed25519_public.pem` (compartilhada para verificação)
  - fingerprint = SHA-256 da chave pública em base64.
- **Formato do QR** (`apps/credentials/services/signing.py`):
  ```
  MRP1.<b64u(canonical_json(payload))>.<b64u(assinatura_64_bytes)>
  ```
  `QR_PREFIX="MRP1."`, `QR_VERSION=1`. `b64u` = base64url sem padding. JSON canônico = chaves ordenadas, sem espaços (`sort_keys=True, separators=(",",":")`), para a assinatura ser determinística.
- **Payload assinado (mínimo, sem PII por LGPD):** só 5 campos:
  `v`=versão (1), `k`=tipo (`m`=member, `v`=vehicle), `ti`=token id UUID4, `iat`=emitido em, `exp`=expira em (`QR_TOKEN_TTL_DAYS`). Nunca nome, e-mail, time ou RA dentro do QR.
- **Verificação em 2 camadas** (`qr_service.verify_qr`):
  1. Cripto: regex de formato, decodifica b64u, `verify_signature()` com a pública. Erro vira `signature` ou `format`.
  2. Banco: busca `QrToken` pelo `ti`. Checa `kind_mismatch` (letra k bate com o dono?), `revoked` (status != active), `expired` (exp no passado), `unknown_token` (ti não existe), e integridade (payload precisa ser igual ao `payload_json` gravado).
- **Revogação:** tabela `QrToken` tem 1 ativo por sujeito (`uniq_qr_active_per_subject`). Emitir novo revoga o anterior na mesma transação. Reemitir resolve QR vencido ou roubado.
- **Impressão:** `segno.make(qr_text, error="q")` — QR Code ISO/IEC 18004 com correção de erro nível Q (recupera ~25% danificado), PNG `scale=6, border=2`, e PDF A4 via `reportlab` (uma linha por membro + chassi).
- **Mesma chave para login:** JWT de staff e de equipe também são EdDSA/Ed25519 (`apps/core/services/jwt_service.py`), claims `{typ, uid/tid, iat, exp, jti}`, TTL 12h (`STAFF_JWT_TTL_HOURS`, `TEAM_JWT_TTL_HOURS`).

### Banco de dados: Django + Postgres

- **Stack:** Django 5.2 + Django REST Framework 3.17.2 + PostgreSQL via `psycopg` 3. Tabelas:
  - `registry.EventSession` (name, kind validation/final, date, status planned/open/closed)
  - `registry.Team` + `TeamAuth` (senha com hash PBKDF2) + `Member` (name, email, ra, role leader/member, 3–5 por time, 1 líder) + `Vehicle` (OneToOne com Team, `conformity_status` denormalizado)
  - `credentials.QrToken` (subject_type member/vehicle, member FK XOR vehicle FK via `ck_qr_token_single_subject`, token_id UUID único, payload_json, signature b64u, status active/revoked)
  - `checkin.CheckIn` (session + subject, idempotente por `uniq_checkin_subject_per_session`, re-bip atualiza `last_seen_at` em vez de duplicar)
  - `checkin.ConformityCheck` (vehicle + session + staff + result pass/fail + items JSON + notes, histórico)
  - `core.AuditLog` (actor, actor_team, action, target_type/id, meta sem PII, ip_hash SHA-256 com salt)
- **Leitura no app Android:** câmera Camera2 (`YUV_420_888`) + ZXing `MultiFormatReader` (`DecodeThread`), HTTP via `HttpURLConnection` (`ApiClient`), token em `SharedPreferences MODE_PRIVATE`. App nunca descriptografa, só transporta `qr_text`.

Arquivos-fonte: `backend/apps/credentials/services/signing.py`, `qr_service.py`, `rendering.py`, `models.py`, `backend/apps/core/services/jwt_service.py`, `backend/apps/checkin/models.py`, `backend/apps/registry/models.py`, `backend/apps/core/models.py`.
